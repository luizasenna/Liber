InfyOm Laravel Generator GUI Builder
=====================================

## Generator GUI Builder is currently in Beta and its not in a sync with current laravel-generator package. We highly recommend to use command line interface.

Documentation is located [here](http://labs.infyom.com/laravelgenerator)

Installation steps are located [here](http://labs.infyom.com/laravelgenerator/docs/5.4/gui-interface)
