$('li.bg-primary').click(function() {
    $('#invoice, #footer-bg').removeAttr('class');
    $('#invoice, #footer-bg').addClass('bg-primary text-white');
});
$('li.bg-success').click(function() {
    $('#invoice, #footer-bg').removeAttr('class');
    $('#invoice, #footer-bg').addClass('bg-success text-white');
});
$('li.bg-warning').click(function() {
    $('#invoice, #footer-bg').removeAttr('class');
    $('#invoice, #footer-bg').addClass('bg-warning text-white');
});
$('li.bg-danger').click(function() {
    $('#invoice, #footer-bg').removeAttr('class');
    $('#invoice, #footer-bg').addClass('bg-danger text-white');
});
$('li.bg-info').click(function() {
    $('#invoice, #footer-bg').removeAttr('class');
    $('#invoice, #footer-bg').addClass('bg-info text-white');
});

$('li.bg-default').click(function() {
    $('#invoice, #footer-bg').removeAttr('class');
    $('#invoice, #footer-bg').addClass('bg-default text-white');
});
